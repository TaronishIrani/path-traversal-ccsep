<!DOCTYPE html>
<html>
    <head>
        <title>Path Traversal Test Site</title>
    </head>
    <body>
        <h1>Path Traversal Test Site Home Page: Script</h1>
        <p>
            This is the page we are going to use to test website redirection exploitation.
        </p>
    </body>
</html>

<html>
        <label for="file">Website to go to:</label><br>
        <input type="text" id="file" name="file"><br>
        <body>
        <input type="submit" onClick="myFunction()"/>
        <script>
        function myFunction() {
            var filename = document.getElementById('file').value;
                
            window.location.href=filename;
        }
        </script>
        </body>
</html>
