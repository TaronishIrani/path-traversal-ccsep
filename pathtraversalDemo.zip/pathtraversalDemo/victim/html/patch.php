
<!DOCTYPE html>
<html>
    <head>
        <title>Path Traversal Test Site</title>
    </head>
    <body>
        <h1>Path Traversal Test Site Home Page: PHP</h1>
        <p>
            This is a very basic website to use for testing
            path traversal exploitation and patching. Path Traversal
            works very similiarly to a SQL Injection attack, so the user
            input box below can be used to test if an attack can be successful.<br>

            <br>I recommend adding a few test files in your webroot folder
            which should be /var/www/pathtraversal/html/... to see if you can access
            them or not.
            <br>We want to see if we can access <b>Testfile</b>.
        </p>
        <p>
            The configuration layout for your testing folder should be as follows:
      </p>
      <pre>
/var/www/pathtraversal/html
|-- index.html
|       
|-- second.html
|      
|-- <b>secretfolder</b>
|      `-- testfile.txt
      </pre>
        
      <form method="get" name="form" action="patch.php">
        <label for="file">File Name to read:</label><br>
        <input type="text" id="file" name="file"><br>
        
      </form>
        <script>
                document.getElementById('submitbutton').onclick = function(){
                var filename = document.getElementById('file').value;
                
                document.getElementById('outputf').innerText = filename;
                
            }
            
        </script>  
        
        File contents are: <span id="outputf"></span><br>
<?php
// THIS IS THE FIRST TYPE OF WAY TO PATCH - RESTRICTING THE USER INPUT
//	$result = $_GET['file'];
//	if(!is_numeric(strpos($result, '/')))
//	{
//		echo file_get_contents($result);
//	}
//	else{
//		echo 'Illegal Characters Found - Not Allowed';
//	}
?>
<?php
//THIS IS THE SECOND WAY TO PATCH - USING THE BASENAME FUNCTION
	$result = $_GET['file'];
	echo '<br>';
	echo basename($result);
	echo '<br>';
//	include "/var/www/pathtraversal/html/".basename($result); - IF YOU WOULD LIKE TO SEE WHAT BASENAME RETURNS
	include "/var/www/pathtraversal/html/safeFolder/".basename($result);
	echo '<br>';
//	echo 'without basename(): '.$result; - IF YOU WOULD LIKE TO SEE WHAT WOULD GET RETURNED WITHOUT BASENAME
?>

        
      
    </body>
</html>

