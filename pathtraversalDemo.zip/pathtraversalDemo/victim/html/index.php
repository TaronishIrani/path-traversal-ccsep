
<!DOCTYPE html>
<html>
    <head>
        <title>Path Traversal Test Site</title>
    </head>
    <body>
        <h1>Path Traversal Test Site Home Page: PHP</h1>
        <p>
            This is a very basic website to use for testing
            path traversal exploitation and patching. Path Traversal
            works very similiarly to a SQL Injection attack, so the user
            input box below can be used to test if an attack can be successful.<br>

            <br>I recommend adding a few test files in your webroot folder
            which should be /var/www/pathtraversal/html/... to see if you can access
            them or not.
            <br>We want to see if we can access <b>Testfile</b>.
        </p>
        <p>
            The configuration layout for your testing folder should be as follows:
      </p>
      <pre>
/var/www/pathtraversal/html
|-- index.html
|       
|-- second.html
|      
|-- <b>secretfolder</b>
|      `-- testfile.txt
      </pre>
	  <?php 
            echo '<form method="POST" action="patch.php">
                <input type="submit" value="Go to patched version"/>
                
                </form>';
        ?>
      <form method="get" name="form" action="index.php">
        <label for="file">File Name to read:</label><br>
        <input type="text" id="file" name="file"><br>
        
      </form>
        <script>
                document.getElementById('submitbutton').onclick = function(){
                var filename = document.getElementById('file').value;
                
                document.getElementById('outputf').innerText = filename;
                
            }
            
        </script>  
        
        File contents are: <span id="outputf"></span><br>
        <?php
	    	$result = $_GET["file"];
		include($result);
        ?>

        
      
    </body>
</html>

